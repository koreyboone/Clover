# Design

## Context

The repository has no application implementation or existing platform constraints. The proposal leaves code, technology, and hardware choices open. The local-only requirement means the two household interfaces must exchange data without an internet service; see `proposal.md` and the `household-routines`, `family-rewards`, and `local-family-data` specs for behavior contracts.

## Goals / Non-Goals

**Goals:**
- Provide one consistent household state for routine runs, approvals, points, and rewards.
- Keep all synchronization on the home network and preserve a useful phone view during display outages.
- Make routine bonuses and reward transactions traceable and resistant to duplicate application.

**Non-Goals:**
- Remote access, cloud backup, accounts, or third-party data processing.
- Multi-household support or synchronization between multiple displays.
- Selecting a framework, database product, or hardware platform before those constraints are known.

## Decisions

### Shared display hosts the authoritative household data

Run the household data service and durable database on the shared display. The parent phone connects as a paired client over the home network: phone administration and child actions are written to the same host state when connected. Keep a local read-only snapshot on the phone for display outages, mark it as potentially stale, and refresh it after reconnection. Disable writes that cannot reach the host rather than queueing ambiguous offline edits.

This avoids cloud hosting and peer-to-peer conflict resolution while providing an authoritative state for both interfaces. A peer-to-peer design would require conflict policies for simultaneous task, approval, and reward changes; making the phone the sole host would leave the shared routine display dependent on the phone being present.

### Keep synchronization independent of internet connectivity

Discover or pair the phone and display on the home network and exchange data directly between them. Use authenticated, encrypted local connections and reject unpaired clients. The system has no cloud endpoint or external analytics path. Local data access and synchronization must not depend on internet availability.

Local-network synchronization is chosen over a cloud relay because the pilot is household-bound and children's data is explicitly local-only. It trades away remote access and requires both devices to share the home network for current data.

### Separate routine definitions from active runs

Store parent-authored routine definitions and schedules separately from dated routine runs. At run creation, snapshot the required tasks and applicable bonus rules so edits made during a run cannot change its requirements. Store task completion, help requests, verification, and skip status against the run.

This makes the next-run configuration rule deterministic and supports review of pilot completion without letting later edits rewrite history.

### Record point changes as explicit transactions

Represent earned bonuses, optional-contribution awards, and redemptions as immutable point-ledger entries associated with the child and source event. Calculate balances from ledger entries or maintain a transactionally updated balance derived from the same entries. Commit each qualifying run bonus and reward redemption atomically, with an idempotency key tied to the run or redemption, so retries cannot award or deduct points twice.

An explicit ledger makes balance changes explainable and enforces the no-deductions rule except for redemption. Updating a balance without recording its cause would make disputes and recovery harder.

### Treat backup restore as a validated replacement

Export the household dataset and its schema/version metadata to a user-selected household location. Before restore, validate the file and supported version without changing active data; require parent confirmation before replacing household data. After a successful restore, refresh the phone cache from the restored host state.

This favors a portable, parent-controlled recovery file over automatic remote backup. Exports can themselves expose children's personal information, so the parent must choose and protect the household destination.

## Risks / Trade-offs

- [The display is a single point of failure for current writes and routine operation] -> Keep the parent phone's last synchronized snapshot readable, communicate when it is stale, and resume synchronization when the display returns.
- [A household LAN may be misconfigured or devices may not discover each other] -> Provide an explicit pairing/setup flow and a clear disconnected state; do not silently fall back to an external service.
- [A backup may be lost, copied, or exposed] -> Keep export user-initiated, warn that it contains children's data, and validate before restore.
- [A device or app failure can still destroy locally stored data] -> Make backup export and restore part of parent setup and pilot operations; local-only storage cannot provide remote disaster recovery.
- [A future technology choice may not support local networking or protected storage] -> Select the platform only after confirming it supports the local-host, local-client, and backup requirements.

## Migration Plan

This is a greenfield application, so no existing data migration is required. Initialize a versioned household data format with the first release. If a later release changes the format, validate and migrate a copy before replacing the current dataset, and preserve a recoverable backup until migration succeeds.
