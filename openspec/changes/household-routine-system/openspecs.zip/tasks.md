# Tasks

## 1. Local Household Platform and Data

- [ ] 1.1 Select a shared-display and parent-phone platform that supports local hosting, authenticated home-network communication, local persistence, and backup; document the hardware assumptions and verify a paired-device proof of concept works with internet disabled.
- [ ] 1.2 Establish the application structure and development/test setup for the selected platform; verify the app starts on both target device types.
- [ ] 1.3 Implement the versioned household data model, persistence, and routine-run snapshots; verify tests cover durable writes, configuration snapshots, and supported data versions.
- [ ] 1.4 Implement paired local-network synchronization with authenticated, encrypted connections; verify connected devices synchronize routine and reward changes without internet and reject an unpaired client.
- [ ] 1.5 Implement the phone's read-only last-synchronized snapshot and stale/disconnected state; verify the snapshot remains viewable while the display is unavailable and refreshes after reconnection.
- [ ] 1.6 Implement parent-triggered backup export and validated, confirmed restore; verify damaged or unsupported backups leave current data unchanged and successful restores refresh the phone.
- [ ] 1.7 Document household setup, device pairing, local-only behavior, disconnected operation, and backup/restore; verify the documented setup and recovery steps against the running app.

## 2. Household Routine Experience

- [ ] 2.1 Implement scheduled routine runs with fixed task and bonus-rule snapshots, completion state, help requests, and skip-day handling; verify tests cover schedule creation and that mid-run edits affect only the next run.
- [ ] 2.2 Implement parent phone controls for tasks, schedules, per-task verification, per-child hide/shorten settings, and exceptions; verify tests confirm one child's settings do not alter another's.
- [ ] 2.3 Implement the shared-display child routine view with text for ages 9 and 10 and icons, optional audio, and at most one parent-assisted task for age 5; verify the views expose the next task and the older children can complete a routine without parent operation.
- [ ] 2.4 Implement child task completion, immediate feedback, one-tap parent verification, and need-help completion; verify tests cover both verified and unverified tasks and assistance counting as completion.
- [ ] 2.5 Implement the scheduled routine cue without overdue labels, countdowns, red warning indicators, streaks, or sibling comparisons; verify UI tests confirm the cue and forbidden indicators are absent.
- [ ] 2.6 Document parent routine setup and exception handling; verify a representative parent can administer a normal routine day in two minutes or less, excluding genuine exceptions.

## 3. Family Rewards

- [ ] 3.1 Implement configurable full and partial routine bonuses, completion thresholds, and skip-day handling using the point ledger; verify tests cover full, partial, no-bonus, assisted completion, skipped runs, no deductions, and duplicate-run protection.
- [ ] 3.2 Implement optional contributions with fixed parent-set values and per-child age-appropriate availability; verify tests confirm only configured contributions award points and responsibilities remain separate from optional work.
- [ ] 3.3 Implement per-child balances, reward catalog and progress, and atomic redemption; verify tests cover immediate visible deductions, insufficient balances, and repeated redemption attempts.
- [ ] 3.4 Implement parent phone management of reward entries, costs, contributions, and point values; verify tests confirm saved changes apply to the intended child without altering other balances, and document reward administration.

## 4. Pilot Readiness and Integration

- [ ] 4.1 Prepare the Phase 1 household configuration for ages 10, 9, and 5, with the pilot routine selected from the week-0 reminder tally; verify the configuration excludes the three-year-old and uses per-task verification appropriate to the participants.
- [ ] 4.2 Run end-to-end tests across the shared display and parent phone with internet disabled; verify routine completion, parent verification, applicable bonus awards, reward redemption, and resumed synchronization after a temporary display outage.
- [ ] 4.3 Write the pilot operating guide for a consistent week-0 manual reminder tally, weeks 1-2 routine use, and weeks 3-4 reminder/completion comparison; verify it covers direct reminders, board cues, arguments, daily administration time, success criteria, and defers a numeric reduction target until baseline data exists.
- [ ] 4.4 Verify the complete pilot flow on the selected household devices, including backup export and restore; document any remaining platform limitations and confirm no children's data leaves household devices.
