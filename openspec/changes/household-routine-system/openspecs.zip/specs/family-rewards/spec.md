# Spec Delta

## Purpose

Family rewards provide transparent, predictable recognition for routine completion and optional contributions while keeping expected responsibilities separate from earned rewards.

## ADDED Requirements

### Requirement: Routine bonuses follow configured completion thresholds
The system SHALL award a full, partial, or no routine bonus according to completion of required tasks and the routine's configured partial threshold; by default, all but one task earns a partial bonus. Incomplete runs SHALL NOT deduct points.

#### Scenario: All required tasks are complete
- **WHEN** all required tasks in a routine run are complete
- **THEN** the child receives the configured full bonus

#### Scenario: Completion meets the partial threshold
- **WHEN** the run does not qualify for the full bonus and its completed tasks meet the configured partial threshold
- **THEN** the child receives the configured partial bonus

#### Scenario: Completion is below the partial threshold
- **WHEN** more required tasks are incomplete than the configured partial threshold permits
- **THEN** the child receives no routine bonus and loses no points

#### Scenario: Parent assistance completes a task
- **WHEN** a required task is completed with parent assistance
- **THEN** it counts as complete when determining the routine bonus

#### Scenario: Routine run is skipped
- **WHEN** a parent skips the routine run for an exception
- **THEN** no routine bonus is awarded and no points are deducted

### Requirement: Routine bonus values are configurable
The system SHALL let a parent configure full and partial bonus values and the maximum number of incomplete tasks allowed for a partial bonus.

#### Scenario: Parent changes bonus rules
- **WHEN** a parent saves new routine bonus values or a partial threshold
- **THEN** the saved rules apply to subsequent eligible routine runs

### Requirement: Optional contributions earn parent-set points
The system SHALL let a parent offer optional contributions with fixed point values and age-appropriate availability per child.

#### Scenario: Child completes an optional contribution
- **WHEN** a child completes an optional contribution under its configured completion rules
- **THEN** the child earns the contribution's fixed point value

### Requirement: Children can see balances and available rewards
The system SHALL show each child their current point balance, the reward catalog, and their progress toward available rewards.

#### Scenario: Child views rewards
- **WHEN** a child opens the rewards view
- **THEN** the view shows that child's balance, available rewards, and progress toward each reward

### Requirement: Reward redemption updates the balance visibly
The system SHALL allow a child to redeem an eligible reward and immediately show the corresponding point deduction.

#### Scenario: Child redeems a reward
- **WHEN** a child redeems a reward costing no more than their available balance
- **THEN** the reward is recorded and the child's balance is immediately reduced by its cost

#### Scenario: Reward costs more than the balance
- **WHEN** a child attempts to redeem a reward costing more than their available balance
- **THEN** the redemption is not completed and the balance remains unchanged

### Requirement: Parents can administer rewards
The system SHALL let a parent manage reward catalog entries, their point costs, optional contributions, and their point values from a phone interface.

#### Scenario: Parent updates a reward
- **WHEN** a parent saves a reward catalog or contribution change from the phone interface
- **THEN** the updated entry is available to the applicable child without changing other children's balances
