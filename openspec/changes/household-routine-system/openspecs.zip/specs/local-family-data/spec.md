# Spec Delta

## Purpose

Local family data keeps children's routine and reward information within household devices, allowing the display and parent phone to work together without accounts, cloud storage, or external data services.

## ADDED Requirements

### Requirement: Children's data stays within the household
The system SHALL store children's data only on household devices and SHALL NOT send it to cloud storage or external services.

#### Scenario: Internet access is unavailable
- **WHEN** the household has no internet access
- **THEN** the system continues to make locally stored routine and reward data available on the household network

#### Scenario: External connectivity is attempted
- **WHEN** the system synchronizes household data
- **THEN** it sends data only between paired household devices over the home network

### Requirement: Parent phone synchronizes with the shared display locally
The system SHALL synchronize routine, completion, verification, and reward data between the shared display and parent phone over the home network.

#### Scenario: Devices are connected to the home network
- **WHEN** the parent phone and shared display are available on the home network
- **THEN** changes made on either device become available on the other without requiring internet access

### Requirement: Parent phone retains a view when the display is unavailable
The parent phone SHALL retain a read-only view of its most recently synchronized household data when the shared display is unavailable.

#### Scenario: Shared display is unavailable
- **WHEN** the parent opens the app on the phone while the shared display cannot be reached
- **THEN** the phone shows the most recently synchronized household data and identifies that it may be out of date

#### Scenario: Shared display becomes available again
- **WHEN** the shared display reconnects to the home network
- **THEN** the phone refreshes its view from the household data and normal synchronization resumes

### Requirement: Parent can export and restore a household backup
The system SHALL let a parent export household data to a household device and restore household data from a valid exported backup.

#### Scenario: Parent exports a backup
- **WHEN** a parent requests a backup export
- **THEN** the system creates an export containing household routine and reward data on a household device without sending it to an external service

#### Scenario: Parent restores a valid backup
- **WHEN** a parent selects a valid backup and confirms restoration
- **THEN** the system restores the backup's household data and makes it available to the shared display and parent phone

#### Scenario: Backup cannot be restored
- **WHEN** a parent selects a damaged or unsupported backup
- **THEN** the system reports that restoration failed and does not replace the current household data

### Requirement: Routine and reward flows work without internet access
The system SHALL support scheduled routine completion, applicable bonuses, and reward redemption on household devices while internet access is disabled.

#### Scenario: Household network remains available without internet
- **WHEN** internet access is disabled but the parent phone and shared display can communicate over the home network
- **THEN** children can complete routines, receive applicable bonuses, and redeem rewards on the household devices
