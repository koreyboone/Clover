# Proposal

## Why

Children currently depend on repeated parental reminders to start and finish household routines. Clover's Phase 1 pilot makes the next task visible, gives children age-appropriate ownership of completion, and uses predictable rules to test whether direct reminders can fall without increasing conflict.

## What Changes

- Add a scheduled, shared-display routine for the children participating in Phase 1, with text-first and picture-led task presentation, child-reported completion, configurable parent verification, and a need-help action.
- Let parents configure routine tasks and schedules, per-child support, skip days, and task verification from a phone. Changes to required tasks during an active routine take effect at its next scheduled run.
- Award mechanical full, partial, or no routine bonuses based on required-task completion; assistance counts as completion, skip days do not penalize, and points are never deducted except for reward redemption.
- Provide per-child point balances, optional paid contributions, and a reward catalog with visible redemption and immediate balance updates.
- Keep children's data on household devices and synchronize the display and parent phone over the home network only. Support routine use while the internet is unavailable, plus parent-triggered backup export and restore.
- Provide a pilot operating guide for a consistent week-0 reminder baseline, weeks 1-2 of routine use, and weeks 3-4 of follow-up completion and reminder checks.
- Exclude the three-year-old, homework points, adaptive routines, streaks, leaderboards, sibling comparisons, and animated characters from Phase 1.

## Capabilities

### New Capabilities
- `household-routines`: Scheduled routines, child task views and completion, parent verification and assistance, skip days, and per-child support.
- `family-rewards`: Routine bonuses, optional contributions, balances, reward catalogs, and redemption.
- `local-family-data`: Local-only household data, home-network synchronization, offline operation, and backup export and restore.

### Modified Capabilities

None.

## Impact

This is a greenfield product change; the repository currently has no application implementation or existing capability specs. It will require a child-facing shared-display experience, a parent phone experience, local household data storage and synchronization, and backup handling. No cloud service, account system, external data service, or LLM is in scope.
